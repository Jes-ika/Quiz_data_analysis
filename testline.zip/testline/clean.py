import json

def clean_current_quiz(data):
    cleaned_questions = []
    for question in data.get("quiz", {}).get("questions", []):
        cleaned_questions.append({
            "id": question.get("id"),
            "description": question.get("description"),
            "options": [
                {
                    "id": option.get("id"),
                    "description": option.get("description"),
                    "is_correct": option.get("is_correct")
                }
                for option in question.get("options", [])
            ]
        })
    return {
        "quiz": {
            "id": data.get("quiz", {}).get("id"),
            "title": data.get("quiz", {}).get("title"),
            "topic": data.get("quiz", {}).get("topic"),
            "questions": cleaned_questions
        }
    }

def clean_historical_quiz(data):
    cleaned_quizzes = []
    for quiz in data:
        cleaned_quizzes.append({
            "id": quiz.get("id"),
            "quiz_id": quiz.get("quiz_id"),
            "score": quiz.get("score"),
            "accuracy": quiz.get("accuracy"),
            "correct_answers": quiz.get("correct_answers"),
            "incorrect_answers": quiz.get("incorrect_answers"),
            "duration": quiz.get("duration"),
            "topic": quiz.get("quiz", {}).get("topic"),
            "questions_count": quiz.get("quiz", {}).get("questions_count")
        })
    return cleaned_quizzes

def clean_quiz_submission(data):
    return {
        "id": data.get("id"),
        "quiz_id": data.get("quiz_id"),
        "user_id": data.get("user_id"),
        "score": data.get("score"),
        "accuracy": data.get("accuracy"),
        "correct_answers": data.get("correct_answers"),
        "incorrect_answers": data.get("incorrect_answers"),
        "duration": data.get("duration"),
        "questions_count": data.get("quiz", {}).get("questions_count")
    }

def main():
    # Load the JSON files
    with open("current_quiz.json", "r") as file:
        current_quiz = json.load(file)
    with open("historical_quiz.json", "r") as file:
        historical_quiz = json.load(file)
    with open("quiz_submission.json", "r") as file:
        quiz_submission = json.load(file)
    
    # Clean the data
    cleaned_current_quiz = clean_current_quiz(current_quiz)
    cleaned_historical_quiz = clean_historical_quiz(historical_quiz)
    cleaned_quiz_submission = clean_quiz_submission(quiz_submission)
    
    # Save the cleaned data
    with open("cleaned_current_quiz.json", "w") as file:
        json.dump(cleaned_current_quiz, file, indent=4)
    with open("cleaned_historical_quiz.json", "w") as file:
        json.dump(cleaned_historical_quiz, file, indent=4)
    with open("cleaned_quiz_submission.json", "w") as file:
        json.dump(cleaned_quiz_submission, file, indent=4)
    
    print("Cleaning complete. Cleaned files saved.")

if __name__ == "__main__":
    main()
