import json
import streamlit as st

# Load the cleaned JSON files
def load_cleaned_data():
    with open('cleaned_current_quiz.json', 'r') as f:
        current_quiz_data = json.load(f)
    with open('cleaned_historical_quiz.json', 'r') as f:
        historical_quiz_data = json.load(f)
    with open('cleaned_quiz_submission.json', 'r') as f:
        quiz_submission_data = json.load(f)
    
    return current_quiz_data, historical_quiz_data, quiz_submission_data

# Analyze historical quiz data
def analyze_historical_data(historical_quiz):
    topic_performance = {}
    skipped_entries = []

    for quiz in historical_quiz:
        try:
            topic = quiz.get("topic", None)
            if topic:
                if topic not in topic_performance:
                    topic_performance[topic] = {
                        "total_score": 0,
                        "total_questions": 0,
                        "correct_answers": 0,
                        "incorrect_answers": 0,
                        "accuracy": [],
                        "attempts": 0
                    }
                
                score = quiz.get("score", 0)
                correct_answers = quiz.get("correct_answers", 0)
                incorrect_answers = quiz.get("incorrect_answers", 0)
                total_questions = quiz.get("questions_count", 0)

                # Update topic performance
                topic_performance[topic]["total_score"] += score
                topic_performance[topic]["correct_answers"] += correct_answers
                topic_performance[topic]["incorrect_answers"] += incorrect_answers
                topic_performance[topic]["total_questions"] += total_questions
                topic_performance[topic]["attempts"] += 1
                
                # Calculate accuracy
                accuracy = (correct_answers / total_questions) * 100 if total_questions else 0
                topic_performance[topic]["accuracy"].append(accuracy)

        except KeyError as e:
            skipped_entries.append(quiz)  # Add skipped entries to the list
    
    return topic_performance, skipped_entries

# Generate insights based on topic performance
def generate_insights(topic_performance):
    insights = {
        "weak_areas": [],
        "improvement_trends": [],
        "performance_gaps": []
    }

    for topic, data in topic_performance.items():
        avg_accuracy = sum(data["accuracy"]) / len(data["accuracy"]) if data["accuracy"] else 0

        # Identify weak areas
        if avg_accuracy < 50:
            insights["weak_areas"].append({
                "topic": topic,
                "average_accuracy": avg_accuracy,
                "attempts": data["attempts"]
            })

        # Identify improvement trends
        if len(data["accuracy"]) > 1 and data["accuracy"][-1] > data["accuracy"][0]:
            insights["improvement_trends"].append({
                "topic": topic,
                "initial_accuracy": data["accuracy"][0],
                "latest_accuracy": data["accuracy"][-1]
            })

        # Identify performance gaps
        if data["total_questions"] > 0:
            performance_gap = data["total_questions"] - data["correct_answers"]
            if performance_gap > 5:  # Threshold for significant gaps
                insights["performance_gaps"].append({
                    "topic": topic,
                    "gap": performance_gap
                })

    return insights

# Create actionable recommendations based on insights
def create_recommendations(insights):
    recommendations = []

    # Weak areas recommendations
    for weak_area in insights["weak_areas"]:
        recommendations.append(f"Focus on the topic '{weak_area['topic']}' where your average accuracy is {weak_area['average_accuracy']:.2f}%. Consider reviewing related materials or practicing similar questions.")

    # Improvement trends recommendations
    for trend in insights["improvement_trends"]:
        recommendations.append(f"Keep up the good work in '{trend['topic']}'. Your accuracy improved from {trend['initial_accuracy']:.2f}% to {trend['latest_accuracy']:.2f}%. Continue practicing to strengthen this trend.")

    # Performance gaps recommendations
    for gap in insights["performance_gaps"]:
        recommendations.append(f"In the topic '{gap['topic']}', there are significant performance gaps with {gap['gap']} unanswered or incorrect questions. Focus on understanding and practicing these concepts.")

    return recommendations

# Analyze and define the student persona
def define_student_persona(topic_performance):
    persona = {}
    strengths = []
    weaknesses = []

    for topic, data in topic_performance.items():
        avg_accuracy = sum(data["accuracy"]) / len(data["accuracy"]) if data["accuracy"] else 0

        # Define strengths and weaknesses
        if avg_accuracy > 80:
            strengths.append(topic)
        elif avg_accuracy < 50:
            weaknesses.append(topic)

    # Define persona labels
    if len(strengths) >= 3:
        persona["label"] = "High Achiever"
        persona["description"] = "Excels in multiple topics with high accuracy."
    elif len(weaknesses) >= 3:
        persona["label"] = "Needs Focus"
        persona["description"] = "Struggles with multiple topics; needs consistent practice."
    else:
        persona["label"] = "Balanced Learner"
        persona["description"] = "Shows moderate performance; some areas need improvement."

    persona["strengths"] = strengths
    persona["weaknesses"] = weaknesses

    return persona

# Perform detailed type analysis for each topic
def topic_analysis(topic_performance):
    detailed_analysis = {}
    for topic, data in topic_performance.items():
        accuracy = sum(data["accuracy"]) / len(data["accuracy"]) if data["accuracy"] else 0
        total_questions = data["total_questions"]
        correct_answers = data["correct_answers"]
        incorrect_answers = data["incorrect_answers"]
        total_score = data["total_score"]

        analysis = {
            "accuracy": accuracy,
            "correct_answers": correct_answers,
            "incorrect_answers": incorrect_answers,
            "total_questions": total_questions,
            "total_score": total_score
        }

        # Classification based on performance
        if accuracy >= 80:
            analysis["type"] = "Excellent"
        elif 50 <= accuracy < 80:
            analysis["type"] = "Good"
        else:
            analysis["type"] = "Needs Improvement"

        detailed_analysis[topic] = analysis

    return detailed_analysis

# Main function to run the analysis and display on Streamlit
def main():
    st.title("Quiz Performance Analyzer")

    current_quiz_data, historical_quiz_data, quiz_submission_data = load_cleaned_data()

    # Analyze historical quiz data
    topic_performance, skipped_entries = analyze_historical_data(historical_quiz_data)

    # Generate insights
    insights = generate_insights(topic_performance)

    # Define student persona
    persona = define_student_persona(topic_performance)

    # Display persona analysis
    st.subheader("Student Persona")
    st.write(f"Label: {persona['label']}")
    st.write(f"Description: {persona['description']}")
    st.write(f"Strengths: {', '.join(persona['strengths']) if persona['strengths'] else 'None'}")
    st.write(f"Weaknesses: {', '.join(persona['weaknesses']) if persona['weaknesses'] else 'None'}")

    # Display insights
    st.subheader("Insights:")
    st.write("### Weak Areas")
    for weak_area in insights["weak_areas"]:
        st.write(f"  - {weak_area['topic']}: Average Accuracy {weak_area['average_accuracy']:.2f}%, Attempts: {weak_area['attempts']}")
    
    st.write("### Improvement Trends")
    for trend in insights["improvement_trends"]:
        st.write(f"  - {trend['topic']}: Improved from {trend['initial_accuracy']:.2f}% to {trend['latest_accuracy']:.2f}%")
    
    st.write("### Performance Gaps")
    for gap in insights["performance_gaps"]:
        st.write(f"  - {gap['topic']}: Performance Gap {gap['gap']} questions")

    # Create recommendations
    recommendations = create_recommendations(insights)

    # Display recommendations
    st.subheader("Recommendations:")
    for recommendation in recommendations:
        st.write(f"- {recommendation}")

    # Perform detailed topic analysis
    st.subheader("Topic Analysis")
    detailed_analysis = topic_analysis(topic_performance)
    for topic, analysis in detailed_analysis.items():
        st.write(f"#### {topic}")
        st.write(f"Accuracy: {analysis['accuracy']:.2f}%")
        st.write(f"Correct Answers: {analysis['correct_answers']}")
        st.write(f"Incorrect Answers: {analysis['incorrect_answers']}")
        st.write(f"Total Questions: {analysis['total_questions']}")
        st.write(f"Total Score: {analysis['total_score']}")
        st.write(f"Performance Type: {analysis['type']}")

    # Display skipped entries
    if skipped_entries:
        st.subheader("Skipped Entries (Missing Data):")
        for entry in skipped_entries:
            st.write(entry)

if __name__ == "__main__":
    main()
